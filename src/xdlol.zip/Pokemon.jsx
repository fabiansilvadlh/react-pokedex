import React, {useState} from 'react'
import { useParams } from 'react-router-dom';
import mockData from './mockData';
import {Typography, capitalize} from '@material-ui/core'

const Pokemon = () => {
  const {pokemonId} = useParams();
  const [pokemon, setPokemon] = useState(mockData[`${pokemonId}`]);

  const generatePokemonJSX = () => {
    const {id, name, species, height, weight, types, sprites} = pokemon;
    const formattedId = `00${id}`.slice(-3) || `0${id}`.slice(-2) || id;

    const fullImageUrl = `https://assets.pokemon.com/assets/cms2/img/pokedex/full/${formattedId}.png`;
    
    const {front_default} = sprites;
    return (
      <>
      <Typography variant="h1">
        {`${id}. ${capitalize(name)}`}
        <img src={front_default} />
      </Typography>
      <img style={{width: '300px', height: '300px'}} src={fullImageUrl} />
      </>
    );

  };

  return  <>{generatePokemonJSX()}</>;
};


export default Pokemon;

